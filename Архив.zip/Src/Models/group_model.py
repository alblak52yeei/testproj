from Src.reference import reference

#
# Модель группу номенклатуры
# 
class group_model(reference):
    def create_group():
        item = group_model("Ингредиенты")
        
        return item